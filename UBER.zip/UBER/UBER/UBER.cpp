#include <iostream>
#include <string>
#include <cstdlib> // for rand() and srand()
#include <ctime>   // for time()

#ifdef _WIN32
#define CLEAR_SCREEN "cls"
#else
#define CLEAR_SCREEN "clear"
#endif

using namespace std;

// Struct to hold car information
struct Car
{
    string name;
    string number;
};

// Function to check if a car has already been used
bool carAlreadyUsed(Car car, Car usedCars[], int numUsedCars);

// Function to randomly select a car name and number
Car getRandomCar(Car usedCars[], int numUsedCars);

// Function declarations for fare calculation
int FAIR1(int speed, int distance, int Timeduration);
int FAIR2(int speed, int distance, int Timeduration);
int FAIR3(int speed, int distance, int Timeduration);

int main()
{
    int fair01, fair02, fair03, distance, Timeduration, speed, R;
    string Timeofarrival, departure, arrival;
    char c;

    // Declaration of cancellationReason variable
    string cancellationReason;

    // Seed the random number generator
    srand(time(0));

    // Print title and ask for user input
    cout << "                       **********UBER************" << endl;
    cout << "                          SPEND LESS TRAVEL MORE" << endl;
    cout << "ENTER YOUR LOCATION: ";
    getline(cin, departure); // Updated input method for departure
    cout << endl << "ENTER YOUR DESTINATION: ";
    getline(cin, arrival); // Updated input method for arrival

    // Generate random distance, time duration, and speed
    distance = rand() % 1001;
    cout << endl << "DISTANCE BETWEEN BOTH LOCATIONS: " << distance << " KM" << endl;

    Timeduration = (rand() % 3) + 1; // Random number between 1 and 3
    int randomMinutes = rand() % 60; // Random number between 0 and 59 for minutes
    cout << "EXPECTED TIME DURATION OF THE RIDE: " << Timeduration << " hours " << randomMinutes << " minutes" << endl;

    speed = rand() % 61 + 40; // Random number between 40 and 100
    cout << "AVERAGE SPEED OF THE CAR DURING RIDE: " << speed << " KM/H" << endl;
    cout << endl;

    // Array to keep track of used cars
    Car usedCars[3];
    // Get three random cars
    Car car1 = getRandomCar(usedCars, 0);
    usedCars[0] = car1;
    Car car2 = getRandomCar(usedCars, 1);
    usedCars[1] = car2;
    Car car3 = getRandomCar(usedCars, 2);

    // Calculate fares for each car type
    fair01 = FAIR1(speed, distance, Timeduration);
    cout << "Fare OF " << car1.name << " IS: " << fair01;
    cout << endl << "COMFORTABILITY OF " << car1.name << " IS 95% WITH AC.." << endl;
    cout << endl;
    fair02 = FAIR2(speed, distance, Timeduration);
    cout << "FARE OF " << car2.name << " IS: " << fair02;
    cout << endl << "COMFORTABILITY OF " << car2.name << " IS 85% WITH AC.." << endl;
    cout << endl;
    fair03 = FAIR3(speed, distance, Timeduration);
    cout << "FARE OF " << car3.name << " IS : " << fair03;
    cout << endl << "COMFORTABILITY OF " << car3.name << " IS 80% WITH AC.." << endl;

    // Assign random values for the expected time of arrival
    int randomHour = rand() % 24;     // Random number between 0 and 23 for hours
    cout << endl << "EXPECTED TIME OF ARRIVAL: " << randomHour << ":" << randomMinutes;

    // Offer vehicle options
    cout << endl << "PRESS A FOR " << car1.name << ".";
    cout << endl << "PRESS B FOR " << car2.name << ".";
    cout << endl << "PRESS C FOR " << car3.name << ".";
    cout << endl << "PRESS D TO CANCEL THE RIDE";
    cout << endl << "CHOOSE YOUR VEHICLE: ";
    cin >> c;

    // Clear the screen and print title again
    system(CLEAR_SCREEN);
    cout << "                       **********UBER************" << endl;
    cout << "                          SPEND LESS TRAVEL MORE" << endl;

    // Process user choice
    if (c == 'A' || c == 'a')
    {
        cout << endl << "YOUR RIDE WILL ARRIVE IN : " << randomHour << ":" << randomMinutes << endl;
        cout << endl << "PLEASE WAIT.";
        cout << endl << "        ******AFTER " << Timeduration << " HOURS " << randomMinutes << " MINUTES********" << endl;
        cout << endl << "              **YOUR TICKET SLIP***" << endl;
        cout << endl << "YOUR DESTINATION HAS ARRIVED.";
        cout << endl << "YOUR RIDE WAS " << car1.name << " AND ITS NUMBER WAS: " << car1.number;
        cout << endl << "YOU REACHED " << arrival << " IN " << Timeduration << " HOURS " << randomMinutes << " MINUTES" << endl;;
        cout << endl << "YOUR FAIR IS: " << fair01;
        cout << endl << "FARE STATUS: PAID";
        cout << endl << "      ******GIVE RATING TO THE RIDER****";
        cout << endl << "PRESS 1 FOR WORST RATING..";
        cout << endl << "PRESS 2 FOR GOOD..";
        cout << endl << "PRESS 3 FOR GREAT..";
        cout << endl << "PRESS 4 FOR NICE..";
        cout << endl << "PRESS 5 FOR EXCELLENT..";
        cout << endl << "CHOOSE YOUR RATING: ";
        cin >> R;

        // Display rating stars
        for (int i = 1; i <= R; i++)
        {
            cout << " * ";
        }

        cout << endl << "THANKS FOR USING OUR SERVICE..";
    }
    else if (c == 'B' || c == 'b')
    {
        cout << endl << "YOUR RIDE WILL ARRIVE IN : " << randomHour << ":" << randomMinutes << endl;
        cout << endl << "PLEASE WAIT....";
        cout << endl << "        ******AFTER " << Timeduration << " HOURS " << randomMinutes << " MINUTES********" << endl;
        cout << endl << "              **YOUR TICKET SLIP***" << endl;
        cout << endl << "YOUR DESTINATION HAS ARRIVED";
        cout << endl << "YOUR RIDE WAS " << car2.name << " AND ITS NUMBER WAS: " << car2.number;
        cout << endl << "YOU REACHED " << arrival << " IN " << Timeduration << " HOURS " << randomMinutes << " MINUTES" << endl;;
        cout << endl << "YOUR FAIR IS: " << fair02;
        cout << endl << "FARE STATUS: PAID";
        cout << endl << "      ******GIVE RATING TO THE RIDER****";
        cout << endl << "PRESS 1 FOR WORST RATING..";
        cout << endl << "PRESS 2 FOR GOOD..";
        cout << endl << "PRESS 3 FOR GREAT..";
        cout << endl << "PRESS 4 FOR NICE..";
        cout << endl << "PRESS 5 FOR EXCELLENT..";
        cout << endl << "CHOOSE YOUR RATING: ";
        cin >> R;

        // Display rating stars
        for (int i = 1; i <= R; i++)
        {
            cout << " * ";
        }

        cout << endl << "THANKS FOR USING OUR SERVICE..";
    }
    else if (c == 'C' || c == 'c')
    {
        cout << endl << "YOUR RIDE WILL ARRIVE IN : " << randomHour << ":" << randomMinutes << endl;
        cout << endl << "PLEASE WAIT....";
        cout << endl << "        ******AFTER " << Timeduration << " HOURS " << randomMinutes << " MINUTES********" << endl;
        cout << endl << "              **YOUR TICKET SLIP***" << endl;
        cout << endl << "YOUR DESTINATION HAS ARRIVED";
        cout << endl << "YOUR RIDE WAS " << car3.name << " AND ITS NUMBER WAS: " << car3.number;
        cout << endl << "YOU REACHED " << arrival << " IN " << Timeduration << " HOURS " << randomMinutes << " MINUTES" << endl;;
        cout << endl << "YOUR FAIR IS: " << fair03;
        cout << endl << "FARE STATUS: PAID";
        cout << endl << "      ******GIVE RATING TO THE RIDER****";
        cout << endl << "PRESS 1 FOR WORST RATING..";
        cout << endl << "PRESS 2 FOR GOOD..";
        cout << endl << "PRESS 3 FOR GREAT..";
        cout << endl << "PRESS 4 FOR NICE..";
        cout << endl << "PRESS 5 FOR EXCELLENT..";
        cout << endl << "CHOOSE YOUR RATING: ";
        cin >> R;

        // Display rating stars
        for (int i = 1; i <= R; i++)
        {
            cout << " * ";
        }

        cout << endl << "THANKS FOR USING OUR SERVICE..";
    }
    else if (c == 'D' || c == 'd')
    {
        int cancelChoice;
        cout << endl << "WHY DO YOU WANT TO CANCEL THE RIDE?" << endl;
        cout << "PRESS 1 FOR DRIVER IS TAKING TOO LONG" << endl;
        cout << "PRESS 2 FOR CHANGE OF PLANS" << endl;
        cout << "PRESS 3 FOR OTHER REASONS" << endl;
        cout << "YOUR CHOICE: ";
        cin >> cancelChoice;

        if (cancelChoice == 1)
            cancellationReason = "DRIVER IS TAKING TOO LONG";
        else if (cancelChoice == 2)
            cancellationReason = "CHANGE OF PLANS";
        else if (cancelChoice == 3)
            cancellationReason = "OTHER REASONS";

        cout << endl << "YOUR RIDE HAS BEEN CANCELED. REASON: " << cancellationReason << endl;
        cout << "THANKS FOR USING OUR SERVICE..";
    }


    cout << endl;
    cout << "--------------------------------------------" << endl;
    cout << "PROJECT CODED AND EXECUTED BY FARHAN AHMAD." << endl;
    cout << "DEPARTMENT OF COMPUTER SCIENCE." << endl;
    cout << "BAHRIA UNIVERSITY ISLAMABAD/PAKISTAN." << endl;
    cout << "--------------------------------------------" << endl;
    return 0;
}

// Function to check if a car has already been used
bool carAlreadyUsed(Car car, Car usedCars[], int numUsedCars)
{
    for (int i = 0; i < numUsedCars; ++i) {
        if (car.name == usedCars[i].name && car.number == usedCars[i].number) {
            return true;
        }
    }
    return false;
}

// Function to randomly select a car name and number
Car getRandomCar(Car usedCars[], int numUsedCars)
{
    // Array of available cars with their names and numbers
    Car cars[] = {
        {"CIVIC", "788"},
        {"CULTUS", "568"},
        {"ELANTRA", "185"},
        {"ALTO", "258"},
        {"WAGONR", "369"}
    };

    // Randomly select a car that hasn't been used yet
    int index;
    do {
        index = rand() % 5;
    } while (carAlreadyUsed(cars[index], usedCars, numUsedCars));

    return cars[index];
}

// Functions for fare calculation...
int FAIR1(int speed, int distance, int Timeduration)
{
    // Adjust fare calculation based on time duration
    return (distance * speed / Timeduration);
}

int FAIR2(int speed, int distance, int Timeduration)
{
    // Adjust fare calculation based on time duration
    return (((distance * speed / Timeduration) / 100) * 90);
}

int FAIR3(int speed, int distance, int Timeduration)
{
    // Adjust fare calculation based on time duration
    return (((distance * speed / Timeduration) / 100) * 95);
}
